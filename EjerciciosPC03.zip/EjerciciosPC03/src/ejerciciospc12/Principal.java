/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciospc12;

/**
 *
 * @author wilme
 */
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        Pila pila = new Pila();
        int opc;

        do {
            String menu =
                  "1. Apilar\n"
                + "2. Desapilar\n"
                + "3. Elemento en la cima\n"
                + "4. Cantidad de elementos\n"
                + "5. ¿Está vacía?\n"
                + "6. ¿Está llena?\n"
                + "7. Mostrar pila\n"
                + "8. Salir";
            String resp = JOptionPane.showInputDialog(null, menu, "Seleccione una opción:", JOptionPane.QUESTION_MESSAGE);
            if (resp == null) break;                  // Cancelar sale
            try { opc = Integer.parseInt(resp); }
            catch (NumberFormatException e) { opc = -1; }

            switch (opc) {
                case 1: {
                    String s = JOptionPane.showInputDialog("Valor a apilar (1–200):");
                    try {
                        int v = Integer.parseInt(s);
                        if (!pila.apilar(v))
                            JOptionPane.showMessageDialog(null, "No se pudo apilar (pila llena o rango inválido).");
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Entrada inválida.");
                    }
                    break;
                }
                case 2: {
                    Integer quit = pila.desapilar();
                    JOptionPane.showMessageDialog(null,
                        (quit == null) ? "Pila vacía." : "Se desapiló: " + quit);
                    break;
                }
                case 3:
                    Integer top = pila.cima();
                    JOptionPane.showMessageDialog(null,
                        (top == null) ? "Pila vacía." : "Cima: " + top);
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Cantidad: " + pila.cantidad());
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null,
                        pila.estaVacia() ? "La pila está vacía." : "La pila NO está vacía.");
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null,
                        pila.estaLlena() ? "La pila está llena." : "La pila NO está llena.");
                    break;
                case 7:
                    JOptionPane.showMessageDialog(null, pila.toString());
                    break;
                case 8:
                    JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        } while (opc != 8);
    }
}

