/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio02;

/**
 *
 * @author wilme
 */
public class Nodo {
    String dato;
    Nodo anterior;
    Nodo siguiente;

    public Nodo(String dato) {
        // Convierte a mayúsculas en el momento de crear el nodo
        this.dato = dato.toUpperCase();
        this.anterior = null;
        this.siguiente = null;
    }
}

