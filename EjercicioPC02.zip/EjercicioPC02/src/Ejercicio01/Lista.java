/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio01;

/**
 *
 * @author wilme
 */
public class Lista {
    private Nodo cabeza;

    public Lista() {
        cabeza = null;
    }

    /** Agrega al final */
    public void agregarAlFinal(int d) {
        Nodo nuevo = new Nodo(d);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo cur = cabeza;
            while (cur.siguiente != null) {
                cur = cur.siguiente;
            }
            cur.siguiente = nuevo;
        }
    }

    /** Agrega después del nodo que contiene 'ref' */
    public boolean agregarEntre(int ref, int d) {
        Nodo cur = cabeza;
        while (cur != null && cur.dato != ref) {
            cur = cur.siguiente;
        }
        if (cur == null) return false;
        Nodo nuevo = new Nodo(d);
        nuevo.siguiente = cur.siguiente;
        cur.siguiente = nuevo;
        return true;
    }

    /** Busca si existe el valor */
    public boolean contiene(int x) {
        Nodo cur = cabeza;
        while (cur != null) {
            if (cur.dato == x) return true;
            cur = cur.siguiente;
        }
        return false;
    }

    /** Cuenta nodos */
    public int cantidad() {
        int cnt = 0;
        Nodo cur = cabeza;
        while (cur != null) {
            cnt++;
            cur = cur.siguiente;
        }
        return cnt;
    }

    /** Elimina y retorna el último, o -1 si estaba vacía */
    public int eliminarFinal() {
        if (cabeza == null) return -1;
        if (cabeza.siguiente == null) {
            int v = cabeza.dato;
            cabeza = null;
            return v;
        }
        Nodo cur = cabeza;
        while (cur.siguiente.siguiente != null) {
            cur = cur.siguiente;
        }
        int v = cur.siguiente.dato;
        cur.siguiente = null;
        return v;
    }

    /** Construye representación en cadena */
    @Override
    public String toString() {
        if (cabeza == null) return "La lista está vacía.";
        StringBuilder sb = new StringBuilder();
        Nodo cur = cabeza;
        while (cur != null) {
            sb.append(cur.dato);
            if (cur.siguiente != null) sb.append(" → ");
            cur = cur.siguiente;
        }
        return sb.toString();
    }
}
