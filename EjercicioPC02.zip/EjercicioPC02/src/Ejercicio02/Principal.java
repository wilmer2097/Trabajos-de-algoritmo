/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio02;

/**
 *
 * @author wilme
 */
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        ListaDoble lista = new ListaDoble();
        int opcion = 0;

        do {
            String menu =
                  "1. Agregar al inicio\n"
                + "2. Agregar entre 2 nodos\n"
                + "3. Mostrar cantidad de nodos\n"
                + "4. Mostrar el primer elemento\n"
                + "5. Eliminar dato de inicio de la lista\n"
                + "6. Mostrar la lista\n"
                + "7. Salir";
            String entrada = JOptionPane.showInputDialog(null, menu, "Entrada", JOptionPane.QUESTION_MESSAGE);
            if (entrada == null) break;  // Cancelar termina el programa

            try {
                opcion = Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opción inválida.");
                continue;
            }

            switch (opcion) {
                case 1:
                    String dato1 = JOptionPane.showInputDialog("Ingrese el dato (se convertirá a MAYÚSCULAS):");
                    if (dato1 != null && !dato1.isEmpty()) {
                        lista.agregarAlInicio(dato1);
                    }
                    break;

                case 2:
                    String ref = JOptionPane.showInputDialog("Dato de referencia:");
                    if (ref != null && !ref.isEmpty()) {
                        String datoNuevo = JOptionPane.showInputDialog("Dato a insertar después de \"" + ref + "\":");
                        if (datoNuevo != null && !datoNuevo.isEmpty()) {
                            boolean ok = lista.agregarEntre(ref, datoNuevo);
                            if (!ok) {
                                JOptionPane.showMessageDialog(null, "Referencia no encontrada.");
                            }
                        }
                    }
                    break;

                case 3:
                    JOptionPane.showMessageDialog(null, "Cantidad de nodos: " + lista.cantidadNodos());
                    break;

                case 4:
                    String primero = lista.primerElemento();
                    if (primero != null) {
                        JOptionPane.showMessageDialog(null, "Primer elemento: " + primero);
                    } else {
                        JOptionPane.showMessageDialog(null, "La lista está vacía.");
                    }
                    break;

                case 5:
                    String eliminado = lista.eliminarInicio();
                    if (eliminado != null) {
                        JOptionPane.showMessageDialog(null, "Se eliminó: " + eliminado);
                    } else {
                        JOptionPane.showMessageDialog(null, "La lista está vacía.");
                    }
                    break;

                case 6:
                    JOptionPane.showMessageDialog(null, lista.toString());
                    break;

                case 7:
                    JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        } while (opcion != 7);
    }
}

