/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciospc34;

/**
 *
 * @author wilme
 */
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        Cola cola = new Cola();
        int opc;

        do {
            String menu =
                  "1. Encolar\n"
                + "2. Desencolar\n"
                + "3. Primer elemento\n"
                + "4. Cantidad de elementos\n"
                + "5. ¿Está vacía?\n"
                + "6. ¿Está llena?\n"
                + "7. Mostrar cola\n"
                + "8. Salir";
            String resp = JOptionPane.showInputDialog(null, menu, "Seleccione una opción:", JOptionPane.QUESTION_MESSAGE);
            if (resp == null) break;
            try { opc = Integer.parseInt(resp); }
            catch (NumberFormatException e) { opc = -1; }

            switch (opc) {
                case 1:
                    String s = JOptionPane.showInputDialog("Cadena a encolar:");
                    if (s != null && !s.isEmpty()) {
                        if (!cola.encolar(s))
                            JOptionPane.showMessageDialog(null, "Cola llena, no se puede encolar.");
                    }
                    break;
                case 2:
                    String dq = cola.desencolar();
                    JOptionPane.showMessageDialog(null,
                        (dq == null) ? "Cola vacía." : "Se desencoló: " + dq);
                    break;
                case 3:
                    String p = cola.primero();
                    JOptionPane.showMessageDialog(null,
                        (p == null) ? "Cola vacía." : "Primero: " + p);
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Cantidad: " + cola.cantidad());
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null,
                        cola.estaVacia() ? "La cola está vacía." : "La cola NO está vacía.");
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null,
                        cola.estaLlena() ? "La cola está llena." : "La cola NO está llena.");
                    break;
                case 7:
                    JOptionPane.showMessageDialog(null, cola.toString());
                    break;
                case 8:
                    JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        } while (opc != 8);
    }
}

