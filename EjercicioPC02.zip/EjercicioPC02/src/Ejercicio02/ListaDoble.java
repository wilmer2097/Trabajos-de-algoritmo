/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio02;

/**
 *
 * @author wilme
 */
public class ListaDoble {
    private Nodo head;  // primer nodo
    private Nodo tail;  // último nodo

    public ListaDoble() {
        head = null;
        tail = null;
    }

    /** 1. Agregar al inicio */
    public void agregarAlInicio(String d) {
        Nodo nuevo = new Nodo(d);
        if (head == null) {
            head = tail = nuevo;
        } else {
            nuevo.siguiente = head;
            head.anterior = nuevo;
            head = nuevo;
        }
    }

    /** 2. Agregar entre 2 nodos (después de ref) */
    public boolean agregarEntre(String ref, String d) {
        if (head == null) return false;
        ref = ref.toUpperCase();
        Nodo cur = head;
        while (cur != null && !cur.dato.equals(ref)) {
            cur = cur.siguiente;
        }
        if (cur == null) return false;  // referencia no encontrada

        Nodo nuevo = new Nodo(d);
        nuevo.siguiente = cur.siguiente;
        nuevo.anterior = cur;
        if (cur.siguiente != null) {
            cur.siguiente.anterior = nuevo;
        } else {
            // si cur era el tail, actualizamos tail
            tail = nuevo;
        }
        cur.siguiente = nuevo;
        return true;
    }

    /** 3. Mostrar cantidad de nodos */
    public int cantidadNodos() {
        int cnt = 0;
        Nodo cur = head;
        while (cur != null) {
            cnt++;
            cur = cur.siguiente;
        }
        return cnt;
    }

    /** 4. Mostrar el primer elemento */
    public String primerElemento() {
        return head != null ? head.dato : null;
    }

    /** 5. Eliminar dato del inicio de la lista */
    public String eliminarInicio() {
        if (head == null) return null;
        String dato = head.dato;
        if (head == tail) {
            // solo un nodo
            head = tail = null;
        } else {
            head = head.siguiente;
            head.anterior = null;
        }
        return dato;
    }

    /** 6. Mostrar la lista completa */
    @Override
    public String toString() {
        if (head == null) return "La lista está vacía.";
        StringBuilder sb = new StringBuilder();
        Nodo cur = head;
        while (cur != null) {
            sb.append(cur.dato);
            if (cur.siguiente != null) sb.append(" ↔ ");
            cur = cur.siguiente;
        }
        return sb.toString();
    }

    /** 7. Verifica si la lista está vacía */
    public boolean estaVacia() {
        return head == null;
    }
}
