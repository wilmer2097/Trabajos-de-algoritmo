/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio01;

/**
 *
 * @author wilme
 */
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        Lista lista = new Lista();
        int opcion = 0;

        do {
            String menu =
                  "1. Agregar al final\n"
                + "2. Agregar entre 2 nodos\n"
                + "3. Buscar un dato\n"
                + "4. Mostrar cantidad de nodos\n"
                + "5. Mostrar la lista\n"
                + "6. Eliminar dato del final de la lista\n"
                + "7. Salir";
            String resp = JOptionPane.showInputDialog(null, menu, "Entrada", JOptionPane.QUESTION_MESSAGE);
            if (resp == null) break;  // Canceló
            try {
                opcion = Integer.parseInt(resp);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opción inválida.");
                continue;
            }

            switch (opcion) {
                case 1: {
                    String s = JOptionPane.showInputDialog("Dato (1–100):");
                    try {
                        int v = Integer.parseInt(s);
                        if (v < 1 || v > 100)
                            throw new NumberFormatException();
                        lista.agregarAlFinal(v);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Ingrese un entero válido entre 1 y 100.");
                    }
                    break;
                }
                case 2: {
                    String sr = JOptionPane.showInputDialog("Referencia (valor existente):");
                    String sn = JOptionPane.showInputDialog("Nuevo dato (1–100):");
                    try {
                        int ref = Integer.parseInt(sr);
                        int v = Integer.parseInt(sn);
                        if (v < 1 || v > 100) throw new NumberFormatException();
                        if (!lista.agregarEntre(ref, v))
                            JOptionPane.showMessageDialog(null, "Referencia no encontrada.");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Datos inválidos.");
                    }
                    break;
                }
                case 3: {
                    String sb = JOptionPane.showInputDialog("Dato a buscar:");
                    try {
                        int x = Integer.parseInt(sb);
                        JOptionPane.showMessageDialog(null,
                            lista.contiene(x) ? "Dato encontrado." : "Dato NO encontrado.");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Entrada inválida.");
                    }
                    break;
                }
                case 4:
                    JOptionPane.showMessageDialog(null, "Cantidad de nodos: " + lista.cantidad());
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, lista.toString());
                    break;
                case 6: {
                    int eliminado = lista.eliminarFinal();
                    if (eliminado == -1)
                        JOptionPane.showMessageDialog(null, "La lista está vacía.");
                    else
                        JOptionPane.showMessageDialog(null, "Se eliminó: " + eliminado);
                    break;
                }
                case 7:
                    JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        } while (opcion != 7);
    }
}
