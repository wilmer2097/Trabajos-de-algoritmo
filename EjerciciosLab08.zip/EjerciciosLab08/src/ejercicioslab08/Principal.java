/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioslab08;
import javax.swing.JOptionPane;
/**
 *
 * @author wilme
 */
public class Principal {
    public static void main(String[] args) {
        Lista lista = new Lista();
        int opcion = 0;

        do {
            String menu =
                  """
                  1. Agregar al inicio
                  2. Agregar al final
                  3. Agregar entre 2 nodos
                  4. Mostrar cantidad de nodos
                  5. Mostrar el primer elemento
                  6. Mostrar el \u00faltimo elemento
                  7. Buscar un dato
                  8. Eliminar dato de inicio de la lista
                  9. Eliminar dato del final de la lista
                  10. Verificar si la lista est\u00e1 vac\u00eda
                  11. Mostrar la lista
                  12. Salir""";

            String entrada = JOptionPane.showInputDialog(null, menu, "Entrada", JOptionPane.QUESTION_MESSAGE);
            if (entrada == null) break;
            try {
                opcion = Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opción inválida.");
                continue;
            }

            switch (opcion) {
                case 1:
                    String dato1 = JOptionPane.showInputDialog("Ingrese el dato:");
                    if (dato1 != null && !dato1.isEmpty())
                        lista.agregarAlInicio(dato1);
                    break;

                case 2:
                    String dato2 = JOptionPane.showInputDialog("Ingrese el dato:");
                    if (dato2 != null && !dato2.isEmpty())
                        lista.agregarAlFinal(dato2);
                    break;

                case 3:
                    String ref = JOptionPane.showInputDialog("Ingrese el dato de referencia:");
                    if (ref != null && !ref.isEmpty()) {
                        if (lista.contiene(ref)) {
                            String datoN = JOptionPane.showInputDialog("Ingrese el dato a insertar después de \"" + ref + "\":");
                            if (datoN != null && !datoN.isEmpty())
                                lista.agregarEntre(ref, datoN);
                        } else {
                            JOptionPane.showMessageDialog(null, "El dato de referencia no existe.");
                        }
                    }
                    break;

                case 4:
                    JOptionPane.showMessageDialog(null, "Cantidad de nodos: " + lista.cantidadNodos());
                    break;

                case 5:
                    if (!lista.estaVacia())
                        JOptionPane.showMessageDialog(null, "Primer elemento: " + lista.primerElemento());
                    else
                        JOptionPane.showMessageDialog(null, "La lista está vacía.");
                    break;

                case 6:
                    if (!lista.estaVacia())
                        JOptionPane.showMessageDialog(null, "Último elemento: " + lista.ultimoElemento());
                    else
                        JOptionPane.showMessageDialog(null, "La lista está vacía.");
                    break;

                case 7:
                    String busq = JOptionPane.showInputDialog("Ingrese el dato a buscar:");
                    if (busq != null)
                        JOptionPane.showMessageDialog(null,
                            lista.contiene(busq) ? "Dato encontrado." : "Dato no encontrado.");
                    break;

                case 8:
                    if (!lista.estaVacia()) {
                        String elim = lista.eliminarInicio();
                        JOptionPane.showMessageDialog(null, "Se eliminó: " + elim);
                    } else {
                        JOptionPane.showMessageDialog(null, "La lista está vacía.");
                    }
                    break;

                case 9:
                    if (!lista.estaVacia()) {
                        String elim2 = lista.eliminarFinal();
                        JOptionPane.showMessageDialog(null, "Se eliminó: " + elim2);
                    } else {
                        JOptionPane.showMessageDialog(null, "La lista está vacía.");
                    }
                    break;

                case 10:
                    JOptionPane.showMessageDialog(null,
                        lista.estaVacia() ? "La lista está vacía." : "La lista NO está vacía.");
                    break;

                case 11:
                    JOptionPane.showMessageDialog(null, lista.toString());
                    break;

                case 12:
                    JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        } while (opcion != 12);
    }
}
