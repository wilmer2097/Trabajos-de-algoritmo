/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciospc34;

/**
 *
 * @author wilme
 */
public class Cola {
    private String[] datos;
    private int frente, fin, tamaño, MAX = 15;

    public Cola() {
        datos = new String[MAX];
        frente = 0;
        fin = -1;
        tamaño = 0;
    }

    // 1. Encolar
    public boolean encolar(String s) {
        if (estaLlena()) return false;
        datos[++fin] = s.toUpperCase();
        tamaño++;
        return true;
    }

    // 2. Desencolar
    public String desencolar() {
        if (estaVacia()) return null;
        String s = datos[frente];
        // mover todos un paso adelante
        for (int i = 0; i < fin; i++) {
            datos[i] = datos[i+1];
        }
        fin--;
        tamaño--;
        return s;
    }

    // 3. Primer elemento
    public String primero() {
        return estaVacia() ? null : datos[frente];
    }

    // 4. Cantidad de elementos
    public int cantidad() {
        return tamaño;
    }

    // 5. Está vacía
    public boolean estaVacia() {
        return tamaño == 0;
    }

    // 6. Está llena
    public boolean estaLlena() {
        return tamaño == MAX;
    }

    // 7. Mostrar cola
    @Override
    public String toString() {
        if (estaVacia()) return "Cola vacía.";
        StringBuilder sb = new StringBuilder();
        for (int i = frente; i <= fin; i++) {
            sb.append(datos[i]).append("\n");
        }
        return sb.toString();
    }
}

