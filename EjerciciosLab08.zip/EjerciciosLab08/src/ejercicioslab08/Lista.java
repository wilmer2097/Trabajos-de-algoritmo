/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioslab08;

/**
 *
 * @author wilme
 */
public class Lista {
    private Nodo cabeza;

    public Lista() {
        cabeza = null;
    }

    // 1. Agregar al inicio
    public void agregarAlInicio(String d) {
        Nodo nuevo = new Nodo(d);
        nuevo.siguiente = cabeza;
        cabeza = nuevo;
    }

    // 2. Agregar al final
    public void agregarAlFinal(String d) {
        Nodo nuevo = new Nodo(d);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo curr = cabeza;
            while (curr.siguiente != null) {
                curr = curr.siguiente;
            }
            curr.siguiente = nuevo;
        }
    }

    // 3. Agregar entre 2 nodos
    public void agregarEntre(String ref, String d) {
        Nodo curr = cabeza;
        while (curr != null && !curr.dato.equals(ref)) {
            curr = curr.siguiente;
        }
        if (curr != null) {
            Nodo nuevo = new Nodo(d);
            nuevo.siguiente = curr.siguiente;
            curr.siguiente = nuevo;
        }
    }

    // 4. Mostrar cantidad de nodos
    public int cantidadNodos() {
        int contador = 0;
        Nodo curr = cabeza;
        while (curr != null) {
            contador++;
            curr = curr.siguiente;
        }
        return contador;
    }

    // 5. Mostrar el primer elemento
    public String primerElemento() {
        return (cabeza != null) ? cabeza.dato : null;
    }

    // 6. Mostrar el último elemento
    public String ultimoElemento() {
        if (cabeza == null) return null;
        Nodo curr = cabeza;
        while (curr.siguiente != null) {
            curr = curr.siguiente;
        }
        return curr.dato;
    }

    // 7. Buscar un dato
    public boolean contiene(String target) {
        Nodo curr = cabeza;
        while (curr != null) {
            if (curr.dato.equals(target)) return true;
            curr = curr.siguiente;
        }
        return false;
    }

    // 8. Eliminar dato de inicio de la lista
    public String eliminarInicio() {
        if (cabeza == null) return null;
        String dato = cabeza.dato;
        cabeza = cabeza.siguiente;
        return dato;
    }

    // 9. Eliminar dato del final de la lista
    public String eliminarFinal() {
        if (cabeza == null) return null;
        if (cabeza.siguiente == null) {
            String dato = cabeza.dato;
            cabeza = null;
            return dato;
        }
        Nodo curr = cabeza;
        while (curr.siguiente.siguiente != null) {
            curr = curr.siguiente;
        }
        String dato = curr.siguiente.dato;
        curr.siguiente = null;
        return dato;
    }

    // 10. Verificar si la lista está vacía
    public boolean estaVacia() {
        return cabeza == null;
    }

    // 11. Mostrar la lista
    @Override
    public String toString() {
        if (cabeza == null) return "La lista está vacía.";
        StringBuilder sb = new StringBuilder();
        Nodo curr = cabeza;
        while (curr != null) {
            sb.append(curr.dato);
            if (curr.siguiente != null) sb.append(" → ");
            curr = curr.siguiente;
        }
        return sb.toString();
    }
}

