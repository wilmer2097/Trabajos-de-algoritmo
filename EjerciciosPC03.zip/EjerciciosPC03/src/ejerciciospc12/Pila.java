/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciospc12;

/**
 *
 * @author wilme
 */
public class Pila {
    private int[] datos;
    private int tope;
    private final int MAX = 10;

    public Pila() {
        datos = new int[MAX];
        tope = -1;
    }

    // 1. Apilar
    public boolean apilar(int valor) {
        if (estaLlena() || valor < 1 || valor > 200) return false;
        datos[++tope] = valor;
        return true;
    }

    // 2. Desapilar
    public Integer desapilar() {
        if (estaVacia()) return null;
        return datos[tope--];
    }

    // 3. Elemento en la cima (peek)
    public Integer cima() {
        if (estaVacia()) return null;
        return datos[tope];
    }

    // 4. Cantidad de elementos
    public int cantidad() {
        return tope + 1;
    }

    // 5. ¿Está vacía?
    public boolean estaVacia() {
        return tope == -1;
    }

    // 6. ¿Está llena?
    public boolean estaLlena() {
        return tope == MAX - 1;
    }

    // 7. Mostrar pila
    @Override
    public String toString() {
        if (estaVacia()) return "Pila vacía.";
        StringBuilder sb = new StringBuilder();
        for (int i = tope; i >= 0; i--) {
            sb.append(datos[i]).append("\n");
        }
        return sb.toString();
    }
}

